.test <- function() BiocGenerics:::testPackage("Biostrings")

